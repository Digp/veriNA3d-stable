#' PDB objects for all canonical bases with reference frame
#'
#' PDB objects for all canonical bases with reference frame
#'
#' @docType data
#'
#' @usage data("refframes")
#'
#' @return Multiple objects with pdb format
#'
"refframes"
